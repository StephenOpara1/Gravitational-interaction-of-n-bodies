const container = document.getElementById('container');
const space = document.getElementById('space');
const spaceCtx = space.getContext('2d');
space.width = window.innerWidth;
space.height = window.innerHeight;
const simData = sessionStorage.getItem('simData');
let frame;

/*updates the value of the range input*/
function intervalfunc(){
    const rangeValue = document.getElementById('rangevalue');
    const times = parseFloat(document.getElementById('timespeed').value);
    rangeValue.innerHTML = times+'x normal speed';
    dt = (1/6) * times;
  };
const delay = 10;
let interval = setInterval(
  intervalfunc, delay);
 
 
/*starts the simulation when button is clicked*/
const start = document.getElementById('start');
const input = document.getElementById('input');
start.addEventListener('click', function() {
  input.style.display = 'none';
  clearInterval(interval);
  container.style.display = 'block';
  motion();
});


/*restarts the animation after button is clicked*/
const restart = document.getElementById('restart');
restart.addEventListener('click', function () {
  location.reload();
});