/*note that the average distance between bodies in meters is equal to 400px of the screen*/
let body = JSON.parse(simData);
/*in meters*/
let scale = 1;
let averageDistance = 0;
let averageCoordinate = {x:0,y:0};
let axisCenter = {x:window.innerWidth/2, y:window.innerHeight/2};

/*functions*/
function distance(x1,y1,x2,y2) {
 var y = (y2-y1)**2;
 var x = (x2-x1)**2;
 var n = (y+x)**0.5
  return n;
}

/*converts meters to pixels by making 70% of window.height/2 equal averageDistance*/
function meterToPixel(m) {
  const p = m*window.innerHeight/((averageDistance/scale)*2);
  return p;
}
/*converts pixel to meters*/
function pixelToMeter(p) {
  const m = p*(averageDistance/scale)/(window.innerHeight/2);
  return m;
}


/*calculates the average distance in metres between bodies*/
for(let k = 1; k < body.length; k++){
  averageDistance += distance(body[0].pX,body[0].pY, body[k].pX, body[k].pY)/(body.length-1);
}

/*calculates the average of the objects coordinates*/
for(let i = 0; i < body.length; i++){
  averageCoordinate.x += body[i].pX/(body.length);
  averageCoordinate.y += body[i].pY/(body.length);
}



const xaxis = document.getElementById('xaxis');
const yaxis = document.getElementById('yaxis');
const topy = document.getElementById('topy');
const bottomy = document.getElementById('bottomy'); 
const rightx = document.getElementById('rightx');
const leftx = document.getElementById('leftx');
const center = document.getElementById('center');


 axisCenter.x -= meterToPixel(averageCoordinate.x);
 axisCenter.y += meterToPixel(averageCoordinate.y);
function grid(){
/*sets the intersection point of the x and y axis*/
xaxis.style.top = axisCenter.y+'px';
yaxis.style.left = axisCenter.x+'px';

topy.innerHTML = (pixelToMeter(axisCenter.y)).toExponential(1)+'m';
topy.style.left = axisCenter.x+'px';

bottomy.innerHTML = (pixelToMeter(axisCenter.y-window.innerHeight)).toExponential(1)+'m';
bottomy.style.left = axisCenter.x+'px';

rightx.innerHTML = (pixelToMeter(window.innerWidth-axisCenter.x)).toExponential(1)+'m';
rightx.style.top = axisCenter.y+'px';

leftx.innerHTML = (pixelToMeter(-axisCenter.x)).toExponential(1)+'m';
leftx.style.top = axisCenter.y+'px';

center.style.left = axisCenter.x +'px';
center.style.top = axisCenter.y +'px';


};

grid();